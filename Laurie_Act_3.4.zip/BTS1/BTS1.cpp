#include<iostream>
#include "BST_V.h"
#include "Funciones.h"
using namespace std;



int main() {
    
    BST t = Funciones::leer();
    t.encontrarMayores();
   
   // t.display();
    /*
    //Complejidad O(n), ya que se pasa por cada nodo una vez
    cout << std::endl;
    cout << "Inorder: ";
    t.inorder();

    //Complejidad O(n), ya que se pasa por cada nodo una vez
    cout << std::endl;
    cout <<"Preorder :";
    t.preorder();

    //Complejidad O(n), ya que se pasa por cada nodo una vez
    cout << std::endl;
    cout << "Postorder :";
    t.postorder();

    //Complejidad O(n), ya que se pasa por cada nodo una vez
    cout << std::endl;
    cout << "La altura del arbol es: " << t.height() << endl;

    // Complejidad O(n^2) ya que pasa una vez por cada nodo para llegar al nivel, aparte de pasar por los dem�s nodos en ese nivel
    cout << std::endl;
    cout << "Level by level" << endl;
    t.levelbylevel();

    // Complejidad O(log n) ya que se hace el procedimiento similar a una b�squeda binaria.
    // Casos de prueba: Principio, en medio, final y cuando el numero no est�. (12, 15, 5, 50)
    cout << std::endl;
    cout << "What level am I (12)?\n";
    t.whatlevelamI(12);

    cout << std::endl;
    cout << "What level am I (15)?\n";
    t.whatlevelamI(15);

    cout << std::endl;
    cout << "What level am I (5)?\n";
    t.whatlevelamI(5);

    cout << std::endl;
    cout << "What level am I (50)?\n";
    t.whatlevelamI(50);


    // Para esta funci�n se usa primeros la funcion existe, que tiene una complejidad O(log n), ya que es una b�squeda "binaria".
    //Dependiendo de si el elemento existe o no, se usa la funci�n ancestors para imprimir los elementos como si se stuvieran buscando, lo que tambi�n es de complejidad O(log n)
    // -> Es de complejidad 2(O(log n)) = O(log n)
    // Casos de prueba: Principio, en medio, final y cuando el numero no est�. (12, 15, 5, 50)
    t.ancestors(12);
    t.ancestors(15);
    t.ancestors(5);
    t.ancestors(50);

    return 0;*/
}
