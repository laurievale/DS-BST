#pragma once
#include<iostream>
#include <stack>
#include <vector>
using namespace std;

class BST {

    struct node {
        int data;
        node* left;
        node* right;
        string ip;
    };

    node* root;

    stack<node*> Orden;

    int height(node* t) {
        if (t == NULL) {
            return 0;
        }
        else {
            int altDerecha = height(t->right);
            int altIzquierda = height(t->left);
            if (altDerecha > altIzquierda) {
                return altDerecha + 1;
            }
            else {
                return altIzquierda + 1;
            }
        }
    }

    node* insert(int x, string ip, node* t)
    {
        if (t == NULL)
        {
            t = new node;
            t->data = x;
            t->ip = ip;
            t->left = t->right = NULL;
        }
        else if (x < t->data)
            t->left = insert(x, ip, t->left);
        else if (x > t->data)
            t->right = insert(x, ip, t->right);
        return t;
    }

    node* find(node* t, int x) {
        if (t == NULL)
            return NULL;
        else if (x < t->data)
            return find(t->left, x);
        else if (x > t->data)
            return find(t->right, x);
        else
            return t;
    }

    node* ancestors(node* t, int x) {
        if (t == NULL)
            cout << "Arbol vacio" << endl;
        else if (x < t->data) {
            cout << t->data << " , ";
            return ancestors(t->left, x);
        }
        else if (x > t->data) {
            cout << t->data << " , ";
            return ancestors(t->right, x);
        }
        else
            // cout << "Ancestros de "<< t << endl;
            return t;
    }

public:
    BST() {
        root = NULL;
    }

    int existe(node* t, int x);

    int whatlevelamI(node* t, int x, int level);

    int heightt(node* t) {
        return height(root);
    }

    void printLevel(node* t, int nivel);

    void insert(int x, string ip);

    void search(int x);

    int height() {
        return height(root);
    }

    void orden(node* t);

    void encontrarMayores();
};