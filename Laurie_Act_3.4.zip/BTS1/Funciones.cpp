#include "Funciones.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
using namespace std;


BST Funciones::leer()
{
    BST arbol = BST();
    string linea;
    string temp1;
    string prev = "";
    int accesos = 1;
    bool primero = true;

    ifstream myFile("ORDENADITOS.txt");
    if (!myFile.is_open()) {
        cout << "Failed to open file" << endl;
    }
    while (getline(myFile, linea)) {
        stringstream ss(linea);
        getline(ss, temp1, ':');

        if (primero) {
            primero = false;
            prev = temp1;
        }

        else {

            if (temp1 == prev) {
                accesos++;
                prev = temp1;
            }
            else {
                arbol.insert(accesos, temp1);
                prev = temp1;
                accesos = 1;
            }
        }

    }

    //arbol.display();
    //arbol.levelbylevel();
    //arbol.postorder();
    //arbol.preorder();
    return arbol;
}
