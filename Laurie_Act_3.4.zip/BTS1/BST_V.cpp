#include "BST_V.h"

int BST::existe(node* t, int x)
{
    
        if (t == NULL)
            return NULL;
        else if (x < t->data)
            return existe(t->left, x);
        else if (x > t->data)
            return existe(t->right, x);
        else if (x == t->data) {
            return 1;
        }
        else {
            return 0;
        }
    
}

int BST::whatlevelamI(node* t, int x, int level)
{
    if (t == NULL)
        return NULL;
    else if (x < t->data)
        return whatlevelamI(t->left, x, level + 1);
    else if (x > t->data)
        return whatlevelamI(t->right, x, level + 1);
    else if (x == t->data) {
        return level + 1;
    }
    else {
        return 0;
    }
}



void BST::printLevel(node* t, int nivel)
{
    if (t == NULL) {
        return;
    }
    if (nivel == 0) {
        cout << t->data << ", ";
    }
    else if (nivel > 0) {
        printLevel(t->left, nivel - 1);
        printLevel(t->right, nivel - 1);
    }
}

void BST::insert(int x, string ip)
{
    root = insert(x, ip, root);
}

void BST::search(int x)
{
    root = find(root, x);
}


void BST::orden(node* t)
{
    if (t == NULL)
        return;
    orden(t->left);
    Orden.push(t);
    orden(t->right);
}

void BST::encontrarMayores()
{
    orden(root);

    for (int i = 0; i < 5; i++) {
        cout << "IP: " << Orden.top()->ip << " ";
        cout << "Accesos : " << Orden.top()->data << endl;
        Orden.pop();
    }
}
