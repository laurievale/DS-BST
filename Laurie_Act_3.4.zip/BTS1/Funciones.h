#pragma once
#include "BST_V.h"
#include <stack>
using namespace std;

class Funciones
{
public:

	static BST leer();

};

